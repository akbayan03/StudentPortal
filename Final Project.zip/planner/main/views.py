from django.shortcuts import render, redirect
from . forms import *
from django.contrib import messages
from django.views import generic
from django.contrib.auth.decorators import login_required
# Create your views here.


@login_required
def home(request):
    return render(request, 'main/home.html')


def notes(request):
    if request.method == "POST":
        form = NotesForm(request.POST)
        if form.is_valid():
            notes = Notes(user=request.user, title=request.POST['title'], description=request.POST['description'])
            notes.save()
        messages.success(request,f"Notes Added from {request.user.username} Successfully!")
    else:
        form = NotesForm()
    notes = Notes.objects.filter(user=request.user)
    context = {'notes': notes, 'form': form}
    return render(request, 'main/notes.html', context)


def delete_notes(request, pk=None):
    Notes.objects.get(id=pk).delete()
    return redirect("main:notes")


class NotesDetailView(generic.DetailView):
    model = Notes


def homework(request):
    if request.method == "POST":
        form = HomeworkForm(request.POST)
        if form.is_valid():
            try:
                finished = request.POST['is finished']
                if finished == 'on':
                    finished = True
                else:
                    finished = False
            except:
                finished = False
            homeworks = Homework(
                    user = request.user,
                    subject = request.POST['subject'],
                    title = request.POST['title'],
                    description = request.POST['description'],
                    due = request.POST['due'],
                    is_finished = finished
                )
            homeworks.save()
            messages.success(request,f'Homework Added from {request.user.username} Successfully!')
    else:
        form = HomeworkForm()
    homework = Homework.objects.filter(user=request.user)
    if len(homework) == 0:
        homeworks_done = True
    else:
        homeworks_done = False
    context = {'homeworks':homework, 'homeworks_done':homeworks_done, 'form':form}
    return render(request, 'main/homework.html', context)


def update_homework(request, pk=None):
    homework = Homework.objects.get(id=pk)
    if homework.is_finished == True:
        homework.is_finished = False
    else:
        homework.is_finished = True
    homework.save()
    return redirect('main:homework')


def delete_homework(request, pk=None):
    Homework.objects.get(id=pk).delete()
    return redirect("main:homework")


def todo(request):
    if request.method == "POST":
        form = TodoForm(request.POST)
        if form.is_valid():
            try:
                finished = request.POST['is finished']
                if finished == 'on':
                    finished = True
                else:
                    finished = False
            except:
                finished = False
            todos = Todo(
                    user = request.user,
                    title = request.POST['title'],
                    is_finished = finished
                )
            todos.save()
            messages.success(request,f'Todo Added from {request.user.username} Successfully!')
    else:
        form = TodoForm()
    todo = Todo.objects.filter(user=request.user)
    if len(todo) == 0:
        todos_done = True
    else:
        todos_done = False
    context = {
        'form':form,
        'todos':todo,
        'todos_done':todos_done
    }
    return render(request, 'main/todo.html', context)


def update_todo(request, pk=None):
    todo = Todo.objects.get(id=pk)
    if todo.is_finished == True:
        todo.is_finished = False
    else:
        todo.is_finished = True
    todo.save()
    return redirect('main:todo')


def delete_todo(request, pk=None):
    Todo.objects.get(id=pk).delete()
    return redirect("main:todo")

